public class LambdaFunction {

  public void handleRequest() {
  }

}
