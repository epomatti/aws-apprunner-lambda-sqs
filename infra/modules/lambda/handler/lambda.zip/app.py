"""Starter code for the lambda handler."""

def lambda_handler():
    """Lambda handler function."""
    print("Handler called!")
  